package test.restapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class restpiApplicationTests {

	@Test
	void contextLoads() {
	}

}
