package test.restapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class restpiApplication {

	public static void main(String[] args) {
		SpringApplication.run(restpiApplication.class, args);
	}

}
