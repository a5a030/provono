package test.restapi.member;

public enum Grade {
    USER,
    ADMIN
}
